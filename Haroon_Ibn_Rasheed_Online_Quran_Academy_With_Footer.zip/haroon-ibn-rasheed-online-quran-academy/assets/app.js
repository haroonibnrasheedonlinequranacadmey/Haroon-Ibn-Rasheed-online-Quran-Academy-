
const demoUsers = {
  admin:   {email:"admin@haroonquranacademy.com", password:"admin123", role:"admin", name:"Academy Admin"},
  teacher: {email:"teacher@haroonquranacademy.com", password:"teacher123", role:"teacher", name:"Demo Teacher"},
  student: {email:"student@haroonquranacademy.com", password:"student123", role:"student", name:"Demo Student"}
};

function setSession(user){ localStorage.setItem("hqa_session", JSON.stringify(user)); }
function getSession(){ try{return JSON.parse(localStorage.getItem("hqa_session"))||null}catch(e){return null} }
function logout(){ localStorage.removeItem("hqa_session"); location.href="index.html"; }

function requireRole(role){
  const s=getSession();
  if(!s){ location.href="index.html"; return null; }
  if(role && s.role!==role){ location.href=s.role==="admin"?"admin-dashboard.html":s.role==="teacher"?"teacher-dashboard.html":"student-dashboard.html"; return null; }
  return s;
}

function login(e){
  e.preventDefault();
  const email=document.getElementById("email").value.trim().toLowerCase();
  const password=document.getElementById("password").value;
  const role=document.getElementById("role").value;
  const user=Object.values(demoUsers).find(u=>u.email===email && u.password===password && u.role===role);
  const msg=document.getElementById("loginMsg");
  if(!user){msg.textContent="Invalid demo login details.";msg.style.color="#c44";return;}
  setSession(user);
  location.href=role==="admin"?"admin-dashboard.html":role==="teacher"?"teacher-dashboard.html":"student-dashboard.html";
}
function fillDemo(){
  const role=document.getElementById("role").value;
  const u=demoUsers[role];
  document.getElementById("email").value=u.email;
  document.getElementById("password").value=u.password;
}
function initRolePage(role){
  const s=requireRole(role);
  if(s){
    document.querySelectorAll("[data-user-name]").forEach(x=>x.textContent=s.name);
    document.querySelectorAll("[data-user-role]").forEach(x=>x.textContent=s.role.toUpperCase());
  }
}
document.addEventListener("DOMContentLoaded",()=>{
  const year=document.querySelector("[data-year]"); if(year) year.textContent=new Date().getFullYear();
});
